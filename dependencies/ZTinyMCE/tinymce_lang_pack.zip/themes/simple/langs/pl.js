tinyMCE.addI18n('pl.simple',{
bold_desc:"Pogrubienie (Ctrl+B)",
italic_desc:"Kursywa (Ctrl+I)",
underline_desc:"Podkre\u015Blenie (Ctrl+U)",
striketrough_desc:"Przekre\u015Blenie",
bullist_desc:"Lista nienumerowana",
numlist_desc:"Lista numerowana",
undo_desc:"Cofnij (Ctrl+Z)",
redo_desc:"Pon\u00F3w (Ctrl+Y)",
cleanup_desc:"Wyczy\u015B\u0107 nieuporz\u0105dkowany kod"
});